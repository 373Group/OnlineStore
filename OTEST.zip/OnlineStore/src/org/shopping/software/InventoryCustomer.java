package org.shopping.software;

import java.awt.Color;
import java.awt.EventQueue;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JTextField;

import org.shopping.people.Employee;
import org.shopping.warehouse.Department;
import org.shopping.warehouse.Item;

import javax.swing.JRadioButton;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class InventoryCustomer {

	public JFrame frame;
	private JTextField txtWhatDoYou;
	private JTextField textField;
	public OnlineStore onlinestore;
	public ArrayList<String> displayVals;
	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					InventoryCustomer window = new InventoryCustomer();
//					window.frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the application.
	 */
	public InventoryCustomer(OnlineStore os) {
		onlinestore = os;
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		boolean eBtn, fBtn, pBtn, phBtn;
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		txtWhatDoYou = new JTextField();
		txtWhatDoYou.setText("What do you want to BUY?");
		txtWhatDoYou.setBounds(111, 6, 175, 26);
		frame.getContentPane().add(txtWhatDoYou);
		txtWhatDoYou.setColumns(10);
		
		JList list = new JList();
		list.setBounds(27, 79, 149, 162);
		frame.getContentPane().add(list);
		
		JRadioButton rdbtnElectronics = new JRadioButton("Electronics");
		rdbtnElectronics.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultListModel<String> listDisplay = new DefaultListModel<>();
				jListFunction("electronics");
				for (String s : displayVals) {
					listDisplay.addElement(s);	
					}
				}
				list.setModel(listDisplay);
				
		});
		rdbtnElectronics.setBounds(121, 44, 77, 23);
		frame.getContentPane().add(rdbtnElectronics);
		
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("Food");
		
		rdbtnNewRadioButton.setBounds(17, 44, 71, 23);
		frame.getContentPane().add(rdbtnNewRadioButton);
	
		JRadioButton rdbtnProduce = new JRadioButton("Produce");
		
		rdbtnProduce.setBounds(210, 44, 62, 23);
		frame.getContentPane().add(rdbtnProduce);
		
		JRadioButton rdbtnPharmacy = new JRadioButton("Pharmacy");
		
		rdbtnPharmacy.setBounds(296, 44, 62, 23);
		frame.getContentPane().add(rdbtnPharmacy);

		fBtn = rdbtnNewRadioButton.isSelected();
		pBtn = rdbtnProduce.isSelected();
		phBtn = rdbtnPharmacy.isSelected();
		
		textField = new JTextField();
		textField.setBounds(326, 105, 88, 26);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JTextArea txtrAddQuantity = new JTextArea();
		txtrAddQuantity.setText("Add Quantity");
		txtrAddQuantity.setBounds(210, 110, 88, 26);
		frame.getContentPane().add(txtrAddQuantity);
		
		JButton btnAddToCart = new JButton("Add to Cart");		
		btnAddToCart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("addToCart Button Pressed");
				if(textField.getText().equals("")) {
					System.out.println("Please enter a Quantity");
					JOptionPane.showMessageDialog(null, "No Quantity Entered" , "EmptyQuantity", JOptionPane.ERROR_MESSAGE);
//				}else if(list) {
//					System.out.println("Please Select an item from a department");
//					JOptionPane.showMessageDialog(null, "No UserName entered " , "Empty UserName", JOptionPane.ERROR_MESSAGE);
//				}else {
//					
//					//add to cart
//					
//					
				}
				
				
			}
		});
		btnAddToCart.setBounds(310, 187, 117, 29);
		frame.getContentPane().add(btnAddToCart);
		
		JButton btnCheckOut = new JButton("Check out");
		btnCheckOut.setBounds(310, 228, 117, 29);
		frame.getContentPane().add(btnCheckOut);
		
		
		
	}
	
	public ArrayList<String> jListFunction(String department){
		
		
		for(Department d : onlinestore.departmentList) {

			if(d.getName().equals(department)) {
				for(Item i : d.getItemList()) {
					displayVals.add(i.getName());
					
				}
			}
		return displayVals;
	}
	
	
	
//	public DefaultListModel<String> jListFunctionElectronics(Boolean eBtn){
//		System.out.println("Adding to JListFuction for Electronics");
//		
//		//DefaultListModel<String> listE = new DefaultListModel<>();  
//		
//		if(eBtn) {
//			for(Department d : onlinestore.departmentList) {
//				//System.out.println(d.getName());
//				if(d.getName().equals("electronics")) {
//					for(Item i : d.getItemList()) {
//						listE.addElement(i.getName()); // need to add quantity
//						System.out.println(i.getName());
//					}
//				}
//			}
//		}else {
//			listE.removeAllElements();
//		}
//		
//		
//		return listE;
//	}
//	
//	public DefaultListModel<String> jListFunctionFood(Boolean fBtn){
//		System.out.println("Adding to JListFuction for Food");
//		
//		//DefaultListModel<String> listF = new DefaultListModel<>();  
//		
//		if(fBtn) {
//			for(Department d : onlinestore.departmentList) {
//				//System.out.println(d.getName());
//				if(d.getName().equals("food")) {
//					for(Item i : d.getItemList()) {
//						listF.addElement(i.getName()); // need to add quantity
//						System.out.println(i.getName());
//					}
//				}
//			}
//		}else {
//			listF.removeAllElements();
//		}
//		
//		
//		return listF;
//	}
//	
//	public DefaultListModel<String> jListFunctionProduce(Boolean pBtn){
//		System.out.println("Adding to JListFuction for Produce");
//		
//		if(pBtn) {
//			for(Department d : onlinestore.departmentList) {
//				if(d.getName().equals("produce")) {
//					for(Item i : d.getItemList()) {
//						listP.addElement(i.getName());
//						System.out.println(i.getName());
//					}
//				}
//			}
//		}else {
//			listP.removeAllElements();
//		}
//		
//		return listP;
//	}
//	
//	public DefaultListModel<String> jListFunctionPharmacy(Boolean phBtn){
//		System.out.println("Adding to JListFuction for Pharmacy");
//		
//		if(phBtn) {
//			for(Department d : onlinestore.departmentList) {
//				if(d.getName().equals("pharmacy")) {
//					for(Item i : d.getItemList()) {
//						listPh.addElement(i.getName());
//						System.out.println(i.getName());
//					}
//				}
//			}
//		}else {
//			listPh.removeAllElements();;
//		}
//		
//		
//		return listPh;
//	}
	
}
